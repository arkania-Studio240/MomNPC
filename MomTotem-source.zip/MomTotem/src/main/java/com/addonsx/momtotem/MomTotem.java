package com.addonsx.momtotem;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class MomTotem extends JavaPlugin implements CommandExecutor {
    private final Set<UUID> claimed = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadClaims();
        getCommand("momtotem").setExecutor(this);
        getLogger().info("MomTotem enabled. Loaded " + claimed.size() + " claim records.");
    }

    private void loadClaims() {
        claimed.clear();
        for (String value : getConfig().getStringList("claimed-uuids")) {
            try {
                claimed.add(UUID.fromString(value));
            } catch (IllegalArgumentException ex) {
                getLogger().warning("Ignoring invalid UUID in claimed-uuids: " + value);
            }
        }
    }

    private boolean saveClaims() {
        getConfig().set("claimed-uuids", claimed.stream().map(UUID::toString).sorted().toList());
        try {
            getConfig().save(getConfigFile());
            return true;
        } catch (IOException ex) {
            getLogger().severe("Could not save claim data. Claim was rolled back: " + ex.getMessage());
            return false;
        }
    }

    private java.io.File getConfigFile() {
        return new java.io.File(getDataFolder(), "config.yml");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // This command is deliberately console-only. FancyNpcs calls console_command,
        // so regular players cannot claim for themselves or for another player.
        if (!(sender instanceof ConsoleCommandSender)) {
            sender.sendMessage(ChatColor.RED + "Este comando solo puede ejecutarlo la consola.");
            return true;
        }

        if (args.length != 2 || !args[0].equalsIgnoreCase("claim")) {
            sender.sendMessage("Uso: momtotem claim <jugador>");
            return true;
        }

        Player player = Bukkit.getPlayerExact(args[1]);
        if (player == null || !player.isOnline()) {
            getLogger().warning("Claim request ignored: player is not online: " + args[1]);
            return true;
        }

        UUID uuid = player.getUniqueId();
        if (claimed.contains(uuid)) {
            player.sendMessage(ChatColor.YELLOW + "Ya reclamaste tu tótem. Solo se entrega uno por jugador.");
            return true;
        }

        if (player.getInventory().firstEmpty() == -1) {
            player.sendMessage(ChatColor.RED + "Dejá al menos un espacio libre en tu inventario y volvé a hablar con mom.");
            return true;
        }

        // Reserve and persist the UUID before giving the item to avoid duplicate claims
        // if the NPC is clicked repeatedly. Roll back if persistence fails.
        claimed.add(uuid);
        if (!saveClaims()) {
            claimed.remove(uuid);
            player.sendMessage(ChatColor.RED + "No se pudo registrar la recompensa. Avisale a un administrador.");
            return true;
        }

        player.getInventory().addItem(new ItemStack(Material.TOTEM_OF_UNDYING, 1));
        player.sendMessage(ChatColor.GREEN + "¡Recibiste tu tótem! Esta recompensa se puede reclamar una sola vez.");
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
        getLogger().info(player.getName() + " claimed the MomTotem reward.");
        return true;
    }
}
